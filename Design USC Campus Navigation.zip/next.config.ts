import type { NextConfig } from 'next'

const publicUrl = process.env.FIGMA_PUBLIC_URL

const nextConfig: NextConfig = {
  // Fully static site: `next build` writes plain HTML/JS/CSS for the static deploy adapter.
  output: 'export',
  images: { unoptimized: true },
  // Deployed builds serve assets from the Figma public URL (same role as Vite's `base`).
  assetPrefix: publicUrl && process.env.NODE_ENV === 'production' ? publicUrl : undefined,
  // Let the Figma Make preview origin load dev resources (HMR, chunks).
  allowedDevOrigins: process.env.FIGMA && publicUrl ? [new URL(publicUrl).hostname] : undefined,
}

export default nextConfig
