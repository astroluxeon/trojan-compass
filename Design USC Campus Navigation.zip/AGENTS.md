# figma-make-app

React + Next.js (App Router) + Tailwind CSS project running inside Figma Make.

## Development Server

A Next.js dev server (`next dev`) is **already running** on `$PORT`, started by `.figma/make/dev`. You don't need to start it manually.

- Preview URL: The user can access the running app through the preview panel
- Hot reload: Changes to source files are reflected immediately

## Project Structure

- `src/app/layout.tsx` - Root layout (Server Component): fonts via `next/font/google`, metadata from `.figma/make/site.json`, imports `globals.css`
- `src/app/page.tsx` - Home route (Server Component): static loading shell plus a `<Suspense>` boundary around the client app
- `src/app/globals.css` - Tailwind CSS v4 import, theme tokens and base styles
- `src/app/robots.ts` - Static `robots.txt` generated from `site.json`
- `src/components/Wayfinder.tsx` - `'use client'` entry for the interactive app (state, deep links via `useSearchParams`, URL sync)
- `src/components/map/*` - three.js scene (react-three-fiber + drei); `MapCanvas` is loaded with `next/dynamic` and `ssr: false`; in-scene labels use `MapHtml`
- `src/components/ui/*` - Sidebar panels, overlays, header, roadmap sheet
- `src/data/*` - Campus buildings, events, floor layouts (`law.ts` is traced from the Gould building map PDF)
- `src/lib/routing.ts` - Indoor/outdoor routing graph and turn-by-turn steps
- `next.config.ts` - Static export (`output: 'export'` to `out/`), Figma asset prefix and preview dev origin
- `postcss.config.mjs` - Tailwind CSS v4 via `@tailwindcss/postcss`
- `.mise.toml` - Toolchain versions for Node.js and pnpm

## Commands

- `pnpm run build` - Production static export to `out/` (pins `NODE_ENV=production`)
- `pnpm run format` - Format with oxfmt

## Styling

Tailwind CSS v4 is configured through PostCSS. `src/app/globals.css` imports Tailwind with `@import 'tailwindcss';` and defines theme tokens in `@theme inline` (font families come from `next/font` CSS variables set in the root layout). Put global element styles inside `@layer base { ... }` so utility classes still apply.

## Next.js notes

- Pages and layouts are Server Components by default; add `'use client'` only at interactive boundaries.
- The site is a static export, so avoid request-time APIs (`cookies()`, `headers()`, server `searchParams`); read query params on the client with `useSearchParams` inside `<Suspense>`.
- Browser-only libraries (three.js/WebGL) must be loaded with `next/dynamic` and `ssr: false` from a Client Component.
