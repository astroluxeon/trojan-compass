import type { Metadata, Viewport } from 'next'
import { Source_Sans_3, Source_Serif_4 } from 'next/font/google'
import site from '../../.figma/make/site.json'
import './globals.css'

const sans = Source_Sans_3({ subsets: ['latin'], variable: '--font-source-sans', display: 'swap' })
const serif = Source_Serif_4({ subsets: ['latin'], variable: '--font-source-serif', weight: ['600', '700'], display: 'swap' })

type SiteConfig = {
  title?: string
  description?: string
  language?: string
  robots?: { index?: boolean }
  icons?: { icon?: string }
}
const config = site as SiteConfig

export const metadata: Metadata = {
  title: config.title ?? 'Trojan Wayfinder · USC Campus Maps',
  description:
    config.description ??
    'Find classrooms, events, restrooms and step-free routes in 3D floor plans of USC buildings.',
  icons: { icon: config.icons?.icon ?? '/favicon.png' },
  robots: config.robots?.index === false ? { index: false, follow: false } : undefined,
}

export const viewport: Viewport = {
  themeColor: '#990000',
}

export default function RootLayout({ children }: { children: React.ReactNode }) {
  return (
    <html lang={config.language ?? 'en'} className={`${sans.variable} ${serif.variable}`}>
      <body>{children}</body>
    </html>
  )
}
