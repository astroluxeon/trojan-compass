import type { MetadataRoute } from 'next'
import site from '../../.figma/make/site.json'

export const dynamic = 'force-static'

export default function robots(): MetadataRoute.Robots {
  const noIndex = (site as { robots?: { index?: boolean } }).robots?.index === false
  return { rules: noIndex ? { userAgent: '*', disallow: '/' } : { userAgent: '*', allow: '/' } }
}
