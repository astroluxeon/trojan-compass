import { Edges, Line } from '@react-three/drei'
import { MapHtml } from './MapHtml'
import { Accessibility, ArrowUpDown, DoorOpen, Footprints, Toilet, TriangleAlert } from 'lucide-react'
import { useState, type ReactNode } from 'react'
import type { BuildingCode } from '../../data/campus'
import {
  cellCenter,
  floorY,
  getLayout,
  getLevels,
  planBounds,
  type Cell,
  type FloorLayout,
} from '../../data/floorplan'
import type { IndoorLeg } from '../../lib/routing'
import { COLORS, type LayerKey } from '../../lib/types'
import { MapBadge } from './Badge'
import { EndPin, RouteLine, StartDot } from './RouteLine'

interface Props {
  code: BuildingCode
  floor: number
  layers: Set<LayerKey>
  highlights: Map<string, string>
  selectedCell?: string
  leg?: IndoorLeg
  isFinalLeg: boolean
  onSelectCell: (cell: Cell) => void
  onSelectFloor: (floor: number) => void
}

const WALL_H = 0.85
const WALL_COLOR = '#c9c9ce'

export function BuildingScene(props: Props) {
  const { code, floor, leg, isFinalLeg } = props
  const levels = getLevels(code)
  const routePts = leg?.points.map((p) => [p.x, p.y + 0.35, p.z] as [number, number, number])
  const last = routePts?.at(-1)
  return (
    <group>
      <mesh rotation={[-Math.PI / 2, 0, 0]} position={[0, floorY(levels[0]) - 0.3, 0]} receiveShadow>
        <planeGeometry args={[400, 400]} />
        <shadowMaterial opacity={0.1} />
      </mesh>
      {levels.map((f) =>
        f === floor ? (
          <ActiveFloor key={f} {...props} />
        ) : (
          <GhostFloor
            key={f}
            code={code}
            floor={f}
            above={f > floor}
            inRoute={!!leg?.floors.includes(f)}
            onClick={() => props.onSelectFloor(f)}
          />
        ),
      )}
      {routePts && last && routePts.length > 1 && (
        <>
          <RouteLine points={routePts} />
          <StartDot position={[routePts[0][0], routePts[0][1] - 0.33, routePts[0][2]]} />
          {isFinalLeg ? (
            <EndPin position={[last[0], last[1] - 0.35, last[2]]} />
          ) : (
            <StartDot position={[last[0], last[1] - 0.33, last[2]]} />
          )}
        </>
      )}
    </group>
  )
}

function Slabs({ layout, color, opacity = 1, edge, depthWrite = true }: { layout: FloorLayout; color: string; opacity?: number; edge: string; depthWrite?: boolean }) {
  return (
    <>
      {layout.slabs.map(([x0, z0, x1, z1], i) => (
        <mesh key={i} position={[(x0 + x1) / 2, -0.12, (z0 + z1) / 2]} receiveShadow={opacity === 1} castShadow={opacity === 1}>
          <boxGeometry args={[x1 - x0 + 0.3, 0.24, z1 - z0 + 0.3]} />
          <meshStandardMaterial color={color} transparent={opacity < 1} opacity={opacity} depthWrite={depthWrite} />
          <Edges color={edge} />
        </mesh>
      ))}
    </>
  )
}

function GhostFloor({ code, floor, above, inRoute, onClick }: { code: BuildingCode; floor: number; above: boolean; inRoute: boolean; onClick: () => void }) {
  const [hover, setHover] = useState(false)
  const layout = getLayout(code, floor)
  const b = planBounds(code)
  return (
    <group
      position={[0, floorY(floor), 0]}
      onClick={(e) => {
        e.stopPropagation()
        onClick()
      }}
      onPointerOver={(e) => {
        e.stopPropagation()
        setHover(true)
        document.body.style.cursor = 'pointer'
      }}
      onPointerOut={() => {
        setHover(false)
        document.body.style.cursor = ''
      }}
    >
      <Slabs
        layout={layout}
        color={hover ? '#e9d6d6' : '#e4e4e7'}
        opacity={above ? (hover ? 0.35 : 0.07) : hover ? 0.8 : 0.55}
        depthWrite={!above}
        edge={inRoute ? (above ? '#e2b4b4' : COLORS.cardinal) : above ? '#d4d4d8' : '#b8b8be'}
      />
      <MapHtml position={[b.x0 + 1.4, 0, b.z1 + 0.9]} center zIndexRange={[20, 0]}>
        <button
          onClick={onClick}
          className={`whitespace-nowrap rounded-full border bg-white px-2 py-0.5 text-[11px] font-semibold shadow-sm transition hover:border-[#990000] hover:text-[#990000] ${
            inRoute ? 'border-[#990000] text-[#990000]' : 'border-neutral-200 text-neutral-500'
          }`}
        >
          {floor === 0 ? 'Basement' : `Floor ${floor}`}
        </button>
      </MapHtml>
    </group>
  )
}

function Wall({ from, to, thick = 0.12 }: { from: [number, number]; to: [number, number]; thick?: number }) {
  const len = Math.hypot(to[0] - from[0], to[1] - from[1])
  if (len < 0.05) return null
  const horizontal = Math.abs(to[1] - from[1]) < 1e-6
  return (
    <mesh position={[(from[0] + to[0]) / 2, WALL_H / 2, (from[1] + to[1]) / 2]} castShadow receiveShadow>
      <boxGeometry args={horizontal ? [len + thick, WALL_H, thick] : [thick, WALL_H, len + thick]} />
      <meshStandardMaterial color={WALL_COLOR} roughness={0.9} />
    </mesh>
  )
}

/** Four walls around a cell, leaving a door gap on the side that holds the door point. */
function CellWalls({ c }: { c: Cell }) {
  const { x0, x1, z0, z1 } = c
  const [dx, dz] = c.door
  const gap = Math.min(c.kind === 'elevator' ? 1.6 : 1.1, Math.min(x1 - x0, z1 - z0) * 0.6)
  const eps = 0.05
  const sides: { a: [number, number]; b: [number, number]; door: boolean; along: 'x' | 'z' }[] = [
    { a: [x0, z0], b: [x1, z0], door: Math.abs(dz - z0) < eps, along: 'x' },
    { a: [x0, z1], b: [x1, z1], door: Math.abs(dz - z1) < eps, along: 'x' },
    { a: [x0, z0], b: [x0, z1], door: Math.abs(dx - x0) < eps, along: 'z' },
    { a: [x1, z0], b: [x1, z1], door: Math.abs(dx - x1) < eps, along: 'z' },
  ]
  return (
    <>
      {sides.map((s, i) => {
        if (!s.door) return <Wall key={i} from={s.a} to={s.b} />
        if (s.along === 'x')
          return (
            <group key={i}>
              <Wall from={s.a} to={[dx - gap / 2, s.a[1]]} />
              <Wall from={[dx + gap / 2, s.a[1]]} to={s.b} />
            </group>
          )
        return (
          <group key={i}>
            <Wall from={s.a} to={[s.a[0], dz - gap / 2]} />
            <Wall from={[s.a[0], dz + gap / 2]} to={s.b} />
          </group>
        )
      })}
    </>
  )
}

function ActiveFloor({ code, floor, layers, highlights, selectedCell, onSelectCell }: Props) {
  const layout = getLayout(code, floor)
  const [hover, setHover] = useState<string | null>(null)
  const accessibleOn = layers.has('accessible')
  const nodeById = new Map(layout.walkNodes.map((n) => [n.id, n]))
  return (
    <group position={[0, floorY(floor), 0]}>
      <Slabs layout={layout} color="#f4f4f6" edge="#b8b8be" />
      {accessibleOn &&
        layout.walkEdges.map(([a, b], i) => {
          const na = nodeById.get(a)!
          const nb = nodeById.get(b)!
          return <Line key={i} points={[[na.x, 0.04, na.z], [nb.x, 0.04, nb.z]]} color={COLORS.accessible} lineWidth={3} transparent opacity={0.75} />
        })}
      {layout.cells.map((c) => {
        const [cx, cz] = cellCenter(c)
        const w = c.x1 - c.x0
        const d = c.z1 - c.z0
        const hl = highlights.get(c.id)
        const selected = selectedCell === c.id
        const hovered = hover === c.id
        const interactive = c.kind !== 'block'
        const base =
          c.kind === 'block'
            ? '#dcdce0'
            : c.open
              ? '#ededf0'
              : c.kind === 'restroom'
                ? '#e1e7ef'
                : c.kind === 'elevator'
                  ? '#d8d8dc'
                  : c.kind === 'stairs'
                    ? '#e6e6e9'
                    : '#e9e9ec'
        const color = selected ? COLORS.cardinal : hl ?? (hovered ? '#e6d3d3' : base)
        return (
          <group key={c.id}>
            <mesh
              position={[cx, c.open ? 0.008 : 0.016, cz]}
              rotation={[-Math.PI / 2, 0, 0]}
              receiveShadow
              onPointerOver={
                interactive
                  ? (e) => {
                      e.stopPropagation()
                      setHover(c.id)
                      document.body.style.cursor = 'pointer'
                    }
                  : undefined
              }
              onPointerOut={
                interactive
                  ? () => {
                      setHover((h) => (h === c.id ? null : h))
                      document.body.style.cursor = ''
                    }
                  : undefined
              }
              onClick={
                interactive
                  ? (e) => {
                      e.stopPropagation()
                      onSelectCell(c)
                    }
                  : undefined
              }
            >
              <planeGeometry args={[w, d]} />
              <meshStandardMaterial color={color} transparent={!!hl && !selected} opacity={hl && !selected ? (c.open ? 0.45 : 0.85) : 1} />
            </mesh>
            {!c.open && <CellWalls c={c} />}
            {c.kind === 'stairs' && <Stairs c={c} />}
            {c.kind === 'elevator' && (
              <mesh position={[cx, 0.6, cz]} castShadow>
                <boxGeometry args={[w * 0.6, 1.2, d * 0.6]} />
                <meshStandardMaterial color="#b6b6bc" roughness={0.6} />
                <Edges color="#9a9aa0" />
              </mesh>
            )}
          </group>
        )
      })}
      <FloorMarkers layout={layout} layers={layers} highlights={highlights} selectedCell={selectedCell} onSelectCell={onSelectCell} />
    </group>
  )
}

function Stairs({ c }: { c: Cell }) {
  const [cx, cz] = cellCenter(c)
  const alongX = c.x1 - c.x0 >= c.z1 - c.z0
  const long = alongX ? c.x1 - c.x0 : c.z1 - c.z0
  const short = alongX ? c.z1 - c.z0 : c.x1 - c.x0
  const n = 6
  const stepLen = (long * 0.8) / n
  const flightW = short * 0.4
  return (
    <group position={[cx, 0, cz]}>
      {[-1, 1].map((sideSign) =>
        Array.from({ length: n }, (_, i) => {
          const along = (sideSign * (long * 0.4 - stepLen * (i + 0.5)))
          const across = sideSign * short * 0.22
          const h = 0.12 + i * 0.16
          return (
            <mesh key={`${sideSign}-${i}`} position={alongX ? [along, h / 2, across] : [across, h / 2, along]} castShadow>
              <boxGeometry args={alongX ? [stepLen, h, flightW] : [flightW, h, stepLen]} />
              <meshStandardMaterial color="#d4d4d8" />
            </mesh>
          )
        }),
      )}
    </group>
  )
}

function FloorMarkers({
  layout,
  layers,
  highlights,
  selectedCell,
  onSelectCell,
}: {
  layout: FloorLayout
  layers: Set<LayerKey>
  highlights: Map<string, string>
  selectedCell?: string
  onSelectCell: (c: Cell) => void
}) {
  const icon = 'h-3.5 w-3.5'
  const markers: { key: string; pos: [number, number, number]; node: ReactNode }[] = []
  for (const c of layout.cells) {
    const [cx, cz] = cellCenter(c)
    const badges: ReactNode[] = []
    if (c.kind === 'block') continue
    if (c.kind === 'room') {
      const hl = highlights.get(c.id)
      const selected = selectedCell === c.id
      if (layers.has('classrooms') || hl || selected) {
        markers.push({
          key: c.id,
          pos: [cx, 1.3, cz],
          node: (
            <button
              onClick={() => onSelectCell(c)}
              title={c.name}
              className="whitespace-nowrap rounded-md border px-1.5 py-0.5 text-[11px] font-bold tabular-nums shadow-sm transition hover:-translate-y-0.5"
              style={
                selected
                  ? { background: COLORS.cardinal, borderColor: COLORS.cardinal, color: '#fff' }
                  : hl
                    ? { background: hl, borderColor: hl, color: hl === '#E8B400' ? '#3b2f00' : '#fff' }
                    : { background: '#fff', borderColor: '#d4d4d8', color: '#262626' }
              }
            >
              {c.label ?? c.number}
            </button>
          ),
        })
      }
      continue
    }
    if (c.kind === 'restroom') {
      if (layers.has('toilets')) badges.push(<MapBadge key="t" color="#3f3f46" title="Restrooms"><Toilet className={icon} /></MapBadge>)
      if (layers.has('accessible')) badges.push(<MapBadge key="a" color={COLORS.accessible} title="Accessible restroom"><Accessibility className={icon} /></MapBadge>)
    }
    if (c.kind === 'elevator') {
      if (layers.has('elevators')) badges.push(<MapBadge key="e" color="#3f3f46" title={c.name}><ArrowUpDown className={icon} /></MapBadge>)
      if (layers.has('accessible')) badges.push(<MapBadge key="a" color={COLORS.accessible} title="Step-free access"><Accessibility className={icon} /></MapBadge>)
    }
    if (c.kind === 'stairs') {
      if (layers.has('stairs')) badges.push(<MapBadge key="s" color="#3f3f46" title={c.name}><Footprints className={icon} /></MapBadge>)
      if (layers.has('exits') && c.core !== 'SC') badges.push(<MapBadge key="x" color={COLORS.exit} title="Emergency exit stair"><DoorOpen className={icon} /></MapBadge>)
    }
    if (badges.length) markers.push({ key: c.id, pos: [cx, 1.5, cz], node: <span className="flex gap-1">{badges}</span> })
  }
  for (const e of layout.entrances) {
    const b: ReactNode[] = []
    if (layers.has('exits')) b.push(<MapBadge key="x" color={COLORS.exit} title={e.label}><DoorOpen className={icon} /></MapBadge>)
    if (layers.has('accessible') && e.stepFree) b.push(<MapBadge key="a" color={COLORS.accessible} title="Step-free entrance"><Accessibility className={icon} /></MapBadge>)
    if (layers.has('accessible') && !e.stepFree) b.push(<MapBadge key="w" color="#B45309" title="Steps at this entrance"><TriangleAlert className={icon} /></MapBadge>)
    if (b.length) markers.push({ key: e.id, pos: [e.x, 1.1, e.z], node: <span className="flex gap-1">{b}</span> })
  }
  return (
    <>
      {markers.map((m) => (
        <MapHtml key={m.key} position={m.pos} center zIndexRange={[20, 0]}>
          {m.node}
        </MapHtml>
      ))}
    </>
  )
}

