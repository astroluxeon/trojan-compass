import {
  Accessibility,
  ArrowUpDown,
  CalendarDays,
  ChevronDown,
  ChevronLeft,
  ChevronRight,
  DoorOpen,
  Footprints,
  Layers,
  MapPin,
  Toilet,
  X,
} from 'lucide-react'
import { useState } from 'react'
import { BUILDING_BY_CODE, EVENT_COLORS, EVENT_LABELS, type EventKind } from '../../data/campus'
import { floorName, floorShort } from '../../data/floorplan'
import type { Route } from '../../lib/routing'
import { COLORS, type LayerKey, type View } from '../../lib/types'
import { STEP_ICONS } from './Directions'

const LAYER_META: { key: LayerKey; label: string; icon: typeof Layers; color: string }[] = [
  { key: 'classrooms', label: 'Classrooms', icon: MapPin, color: '#262626' },
  { key: 'events', label: 'Classes & events', icon: CalendarDays, color: COLORS.cardinal },
  { key: 'toilets', label: 'Restrooms', icon: Toilet, color: '#3f3f46' },
  { key: 'accessible', label: 'Accessible paths', icon: Accessibility, color: COLORS.accessible },
  { key: 'elevators', label: 'Elevators', icon: ArrowUpDown, color: '#3f3f46' },
  { key: 'stairs', label: 'Stairs', icon: Footprints, color: '#3f3f46' },
  { key: 'exits', label: 'Emergency exits', icon: DoorOpen, color: COLORS.exit },
]

export function LayerPanel({ layers, onToggle }: { layers: Set<LayerKey>; onToggle: (k: LayerKey) => void; view: View }) {
  const [open, setOpen] = useState(true)
  return (
    <div className="absolute bottom-4 left-4 z-30 w-56 overflow-hidden rounded-xl border border-neutral-200 bg-white/95 shadow-[0_4px_16px_rgba(0,0,0,0.08)] backdrop-blur max-md:w-52">
      <button onClick={() => setOpen(!open)} className="flex w-full items-center justify-between px-3 py-2.5 text-[13px] font-bold">
        <span className="flex items-center gap-2">
          <Layers className="h-4 w-4 text-cardinal" /> Map layers
        </span>
        <ChevronDown className={`h-4 w-4 text-neutral-400 transition ${open ? '' : '-rotate-90'}`} />
      </button>
      {open && (
        <div className="border-t border-neutral-100 px-1.5 pb-2 pt-1">
          {LAYER_META.map(({ key, label, icon: Icon, color }) => {
            const on = layers.has(key)
            return (
              <button
                key={key}
                onClick={() => onToggle(key)}
                role="switch"
                aria-checked={on}
                className="flex w-full items-center gap-2.5 rounded-md px-1.5 py-1 text-left transition hover:bg-neutral-50"
              >
                <span className="grid h-5 w-5 place-items-center rounded-full text-white transition" style={{ background: on ? color : '#d4d4d8' }}>
                  <Icon className="h-3 w-3" />
                </span>
                <span className={`flex-1 text-[13px] ${on ? 'font-semibold text-neutral-800' : 'text-neutral-400'}`}>{label}</span>
                <span className={`relative h-4 w-7 rounded-full transition ${on ? 'bg-cardinal' : 'bg-neutral-200'}`}>
                  <span className={`absolute top-0.5 h-3 w-3 rounded-full bg-white shadow transition-all ${on ? 'left-3.5' : 'left-0.5'}`} />
                </span>
              </button>
            )
          })}
          {layers.has('events') && (
            <div className="mt-1 flex flex-wrap gap-x-3 gap-y-1 border-t border-neutral-100 px-1.5 pt-2">
              {(Object.keys(EVENT_COLORS) as EventKind[]).map((k) => (
                <span key={k} className="flex items-center gap-1.5 text-[11px] text-neutral-500">
                  <span className="h-2 w-2 rounded-sm" style={{ background: EVENT_COLORS[k] }} />
                  {EVENT_LABELS[k]}
                </span>
              ))}
            </div>
          )}
        </div>
      )}
    </div>
  )
}

export function FloorSelector({
  levels,
  floor,
  routeFloors,
  onSelect,
}: {
  levels: number[]
  floor: number
  routeFloors: number[]
  onSelect: (f: number) => void
}) {
  return (
    <div className="absolute right-4 top-1/2 z-30 flex -translate-y-1/2 flex-col items-center gap-1 rounded-xl border border-neutral-200 bg-white p-1 shadow-[0_4px_16px_rgba(0,0,0,0.08)]">
      <span className="px-1 pb-0.5 pt-1 text-[9px] font-bold uppercase tracking-[0.14em] text-neutral-400">Floor</span>
      {[...levels].reverse().map((f) => (
        <button
          key={f}
          onClick={() => onSelect(f)}
          aria-label={floorName(f)}
          aria-pressed={f === floor}
          className={`relative grid h-9 w-9 place-items-center rounded-lg text-[14px] font-bold transition ${
            f === floor ? 'bg-cardinal text-white' : 'text-neutral-600 hover:bg-neutral-100'
          }`}
        >
          {floorShort(f)}
          {routeFloors.includes(f) && f !== floor && <span className="absolute right-1 top-1 h-1.5 w-1.5 rounded-full bg-cardinal" />}
        </button>
      ))}
    </div>
  )
}

export function Breadcrumb({ view, onCampus }: { view: View; onCampus: () => void }) {
  return (
    <div className="absolute left-4 top-4 z-30 flex items-center gap-1 rounded-full border border-neutral-200 bg-white/95 px-1.5 py-1 text-[13px] shadow-sm backdrop-blur">
      <button
        onClick={onCampus}
        className={`rounded-full px-2.5 py-1 font-semibold transition ${view.type === 'campus' ? 'text-neutral-900' : 'text-neutral-500 hover:bg-neutral-100 hover:text-cardinal'}`}
      >
        University Park Campus
      </button>
      {view.type === 'building' && (
        <>
          <ChevronRight className="h-3.5 w-3.5 text-neutral-300" />
          <span className="flex items-center gap-1.5 px-1.5 font-semibold">
            <span className="rounded bg-cardinal px-1.5 py-0.5 text-[11px] font-bold text-white">{view.code}</span>
            <span className="max-md:hidden">{BUILDING_BY_CODE[view.code].name}</span>
          </span>
          <ChevronRight className="h-3.5 w-3.5 text-neutral-300" />
          <span className="pr-2.5 font-semibold text-neutral-600">{floorName(view.floor)}</span>
        </>
      )}
    </div>
  )
}

export function CampusHint() {
  return (
    <div className="pointer-events-none absolute left-1/2 top-4 z-20 -translate-x-1/2 rounded-full bg-neutral-900/85 px-4 py-2 text-[13px] font-medium text-white shadow-lg max-lg:hidden">
      Click a building or its code to see its floors. Try LAW for floor plans from the real Gould building map.
    </div>
  )
}

export function RouteBar({
  route,
  active,
  onStep,
  onClose,
}: {
  route: Route
  active: number
  onStep: (i: number) => void
  onClose: () => void
}) {
  const step = route.steps[active]
  const Icon = STEP_ICONS[step.icon]
  return (
    <div className="absolute left-1/2 top-16 z-30 w-[min(520px,calc(100%-2rem))] -translate-x-1/2">
      <div className="flex items-center gap-3 rounded-xl bg-neutral-900 p-2 pl-3 text-white shadow-xl">
        <span className={`grid h-9 w-9 shrink-0 place-items-center rounded-full ${step.icon === 'arrive' ? 'bg-cardinal' : step.icon === 'elevator' ? 'bg-[#1F5BA8]' : 'bg-white/10'}`}>
          <Icon className="h-4 w-4" />
        </span>
        <div key={active} className="animate-fade-up min-w-0 flex-1">
          <div className="text-[11px] font-semibold uppercase tracking-wider text-white/50">
            Step {active + 1} of {route.steps.length}
            {step.building ? ` · ${step.building} ${floorName(step.floor ?? 1).toLowerCase()}` : ' · Outdoors'}
          </div>
          <div className="text-[14px] font-medium leading-snug">{step.text}</div>
        </div>
        <div className="flex shrink-0 items-center gap-1">
          <button aria-label="Previous step" disabled={active === 0} onClick={() => onStep(active - 1)} className="grid h-8 w-8 place-items-center rounded-lg bg-white/10 transition hover:bg-white/20 disabled:opacity-30">
            <ChevronLeft className="h-4 w-4" />
          </button>
          <button aria-label="Next step" disabled={active === route.steps.length - 1} onClick={() => onStep(active + 1)} className="grid h-8 w-8 place-items-center rounded-lg bg-gold text-neutral-900 transition hover:bg-[#ffd633] disabled:opacity-30">
            <ChevronRight className="h-4 w-4" />
          </button>
          <button aria-label="End route" onClick={onClose} className="grid h-8 w-8 place-items-center rounded-lg text-white/60 transition hover:bg-white/10 hover:text-white">
            <X className="h-4 w-4" />
          </button>
        </div>
      </div>
    </div>
  )
}
