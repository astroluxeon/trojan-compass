import { Accessibility, CalendarDays, Lightbulb, Map as MapIcon } from 'lucide-react'

export type NavKey = 'explore' | 'events' | 'accessibility'

interface Props {
  active: NavKey
  onNav: (k: NavKey) => void
  onRoadmap: () => void
}

const NAV: { key: NavKey; label: string; icon: typeof MapIcon }[] = [
  { key: 'explore', label: 'Explore', icon: MapIcon },
  { key: 'events', label: 'Events', icon: CalendarDays },
  { key: 'accessibility', label: 'Accessibility', icon: Accessibility },
]

export function Header({ active, onNav, onRoadmap }: Props) {
  return (
    <header className="relative z-40 shrink-0 bg-cardinal text-white">
      <div className="flex h-14 items-center gap-6 px-4 md:px-6">
        <a href="#" className="flex items-center gap-3" aria-label="USC Trojan Wayfinder home">
          <span className="font-display text-[26px] font-bold leading-none tracking-tight">USC</span>
          <span className="h-7 w-px bg-white/30" />
          <span className="leading-tight">
            <span className="block text-[15px] font-semibold">Trojan Wayfinder</span>
            <span className="block text-[11px] uppercase tracking-[0.14em] text-white/70">Campus Maps · Indoor 3D</span>
          </span>
        </a>
        <nav className="ml-4 hidden h-full items-stretch md:flex">
          {NAV.map(({ key, label, icon: Icon }) => (
            <button
              key={key}
              onClick={() => onNav(key)}
              className={`relative flex items-center gap-2 px-4 text-[14px] font-semibold transition ${
                active === key ? 'text-white' : 'text-white/75 hover:text-white'
              }`}
            >
              <Icon className="h-4 w-4" />
              {label}
              {active === key && <span className="absolute inset-x-3 bottom-0 h-[3px] rounded-t bg-gold" />}
            </button>
          ))}
        </nav>
        <button
          onClick={onRoadmap}
          className="ml-auto flex items-center gap-2 rounded-full border border-white/40 px-4 py-1.5 text-[14px] font-semibold text-white transition hover:border-gold hover:text-gold"
        >
          <Lightbulb className="h-4 w-4" />
          <span className="hidden sm:inline">Product roadmap</span>
          <span className="sm:hidden">Roadmap</span>
        </button>
      </div>
    </header>
  )
}
