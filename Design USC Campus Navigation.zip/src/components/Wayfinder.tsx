'use client'

import dynamic from 'next/dynamic'
import { useSearchParams } from 'next/navigation'
import { useEffect, useMemo, useRef, useState } from 'react'
import { BUILDING_BY_CODE, EVENT_COLORS, EVENTS, type BuildingCode, type CampusEvent } from '@/data/campus'
import {
  accessibleEntrancePlace,
  entrancePlace,
  findCell,
  findPlace,
  getFloorCells,
  getLevels,
  placeFromCell,
  randomRoomPlace,
  type Cell,
  type Place,
} from '@/data/floorplan'
import { computeRoute, type Route, type RouteMode } from '@/lib/routing'
import type { LayerKey, View } from '@/lib/types'
import { COLORS } from '@/lib/types'
import { MapLoading } from './AppShellFallback'

// three.js needs WebGL and `window`, so the canvas only ever renders in the browser.
const MapCanvas = dynamic(() => import('./map/MapCanvas').then((m) => m.MapCanvas), {
  ssr: false,
  loading: () => <MapLoading />,
})
import { DirectionsCard } from './ui/Directions'
import { Header, type NavKey } from './ui/Header'
import { Breadcrumb, CampusHint, FloorSelector, LayerPanel, RouteBar } from './ui/MapOverlays'
import {
  BuildingGrid,
  BuildingHeader,
  EventList,
  FloorDirectory,
  SearchBox,
  SelectedRoomCard,
  WelcomeCard,
  eventPlaceId,
  type EventFilter,
  type Persona,
} from './ui/Panels'
import { RoadmapSheet } from './ui/RoadmapSheet'

const DEFAULT_LAYERS: LayerKey[] = ['classrooms', 'events', 'toilets', 'elevators', 'exits']
const ACCESS_LAYERS: LayerKey[] = ['accessible', 'toilets', 'elevators', 'exits']

/**
 * Deep links let the existing USC map hand off to this viewer, e.g.
 * ?building=LAW&floor=B or ?room=LAW-107 or ?from=LAW-ENT-EAST&to=LAW-433&mode=elevator
 */
function readDeepLink(q: URLSearchParams) {
  const code = q.get('building')?.toUpperCase() as BuildingCode | undefined
  const b = code ? BUILDING_BY_CODE[code] : undefined
  const levels = b ? getLevels(b.code) : [1]
  const wanted = q.get('floor') === 'B' ? 0 : Number(q.get('floor') ?? 1)
  const floor = levels.includes(wanted) ? wanted : levels.includes(1) ? 1 : levels[0]
  const room = q.get('room') ? findPlace(q.get('room')!.toUpperCase()) : undefined
  const from = q.get('from') ? findPlace(q.get('from')!.toUpperCase()) : undefined
  const to = q.get('to') ? findPlace(q.get('to')!.toUpperCase()) : undefined
  const m = q.get('mode')
  const mode: RouteMode = m === 'stairs' || m === 'elevator' ? m : 'fastest'
  const route = from && to ? computeRoute(from, to, mode) : null
  let view: View = { type: 'campus' }
  if (route?.steps[0].building) view = { type: 'building', code: route.steps[0].building, floor: route.steps[0].floor ?? 1 }
  else if (room) view = { type: 'building', code: room.building, floor: room.floor }
  else if (b) view = { type: 'building', code: b.code, floor }
  return { view, room, from: from ?? null, to: to ?? null, mode, route }
}

export default function Wayfinder() {
  const searchParams = useSearchParams()
  const [link] = useState(() => readDeepLink(new URLSearchParams(searchParams.toString())))
  const [view, setView] = useState<View>(link.view)
  const [layers, setLayers] = useState<Set<LayerKey>>(() => new Set(DEFAULT_LAYERS))
  const [nav, setNav] = useState<NavKey>('explore')
  const [persona, setPersona] = useState<Persona>('first-year')
  const [eventFilter, setEventFilter] = useState<EventFilter>('all')
  const [from, setFrom] = useState<Place | null>(link.from)
  const [to, setTo] = useState<Place | null>(link.to)
  const [mode, setMode] = useState<RouteMode>(link.mode)
  const [route, setRoute] = useState<Route | null>(link.route)
  const [activeStep, setActiveStep] = useState(0)
  const [selectedCell, setSelectedCell] = useState<string | undefined>(link.room?.id ?? (link.to?.kind !== 'entrance' ? link.to?.id : undefined))
  const [roadmap, setRoadmap] = useState(false)
  const sidebarRef = useRef<HTMLElement>(null)
  const eventsRef = useRef<HTMLDivElement>(null)

  const highlights = useMemo(() => {
    const m = new Map<string, string>()
    if (layers.has('events')) {
      for (const e of EVENTS) if (eventFilter === 'all' || e.kind === eventFilter) m.set(eventPlaceId(e), EVENT_COLORS[e.kind])
    }
    if (route?.to.kind === 'room') m.set(route.to.id, COLORS.cardinal)
    return m
  }, [layers, eventFilter, route])

  // Keep the address bar shareable: it mirrors the current building, floor, room and route.
  useEffect(() => {
    const q = new URLSearchParams()
    if (route) {
      q.set('from', route.from.id)
      q.set('to', route.to.id)
      if (route.mode !== 'fastest') q.set('mode', route.mode)
    } else if (view.type === 'building') {
      q.set('building', view.code)
      q.set('floor', view.floor === 0 ? 'B' : String(view.floor))
      if (selectedCell) q.set('room', selectedCell)
    }
    const next = q.toString() ? `?${q}` : window.location.pathname
    if (next !== window.location.search) window.history.replaceState(null, '', next)
  }, [view, selectedCell, route])

  const suggestions = useMemo<Place[]>(() => {
    if (view.type === 'building') {
      const cells = getFloorCells(view.code, view.floor)
      const special = cells.filter((c) => c.kind === 'restroom' || c.kind === 'elevator').map(placeFromCell)
      const rooms = cells.filter((c) => c.kind === 'room').map(placeFromCell)
      return [entrancePlace(view.code), accessibleEntrancePlace(view.code), ...special, ...rooms].filter(
        (p, i, a) => a.findIndex((x) => x.id === p.id) === i,
      )
    }
    const eventPlaces = EVENTS.map((e) => findPlace(eventPlaceId(e))).filter(Boolean) as Place[]
    return [entrancePlace('LAW'), accessibleEntrancePlace('LAW'), ...eventPlaces.slice(0, 4)]
  }, [view])

  const openBuilding = (code: BuildingCode, floor = 1) => {
    setView({ type: 'building', code, floor })
    setSelectedCell(undefined)
  }

  const goToStep = (i: number, r: Route | null = route) => {
    if (!r) return
    setActiveStep(i)
    const step = r.steps[i]
    if (step.building) setView({ type: 'building', code: step.building, floor: step.floor ?? 1 })
    else setView({ type: 'campus' })
  }

  const runRoute = (f: Place, t: Place, m: RouteMode = mode) => {
    setFrom(f)
    setTo(t)
    setMode(m)
    const r = computeRoute(f, t, m)
    setRoute(r)
    if (r) {
      if (t.kind !== 'entrance') setSelectedCell(t.id)
      goToStep(0, r)
    }
  }

  const clearRoute = () => {
    setRoute(null)
    setActiveStep(0)
  }

  const randomRoute = () => {
    const building = view.type === 'building' ? view.code : undefined
    const f = from ?? (mode === 'elevator' ? accessibleEntrancePlace : entrancePlace)(building ?? 'LAW')
    runRoute(f, randomRoomPlace(building ?? f.building, f.id))
  }

  const openEvent = (e: CampusEvent) => {
    const place = findPlace(eventPlaceId(e))
    if (!place) return
    setTo(place)
    setView({ type: 'building', code: e.building, floor: place.floor })
    setSelectedCell(place.id)
  }

  const openPlace = (p: Place) => {
    setView({ type: 'building', code: p.building, floor: p.floor })
    setSelectedCell(p.kind === 'entrance' ? undefined : p.id)
  }

  const selectCell = (c: Cell) => {
    setSelectedCell(c.id)
    if (view.type === 'building' && view.floor !== c.floor) setView({ ...view, floor: c.floor })
  }

  const enableAccessibility = () => {
    setLayers((l) => new Set([...l, ...ACCESS_LAYERS]))
    setMode('elevator')
    if (route) runRoute(route.from, route.to, 'elevator')
  }

  const onNav = (k: NavKey) => {
    setNav(k)
    if (k === 'accessibility') enableAccessibility()
    if (k === 'events') {
      setLayers((l) => new Set([...l, 'events']))
      setEventFilter('all')
      requestAnimationFrame(() => eventsRef.current?.scrollIntoView({ behavior: 'smooth', block: 'start' }))
    }
    if (k === 'explore') {
      setLayers(new Set(DEFAULT_LAYERS))
      sidebarRef.current?.scrollTo({ top: 0, behavior: 'smooth' })
    }
  }

  const welcomeCta = () => {
    const ev = EVENTS.find((e) => e.id === (persona === 'first-year' ? 'e1' : 'e3'))!
    const dest = findPlace(eventPlaceId(ev))
    if (dest) runRoute((mode === 'elevator' ? accessibleEntrancePlace : entrancePlace)(ev.building), dest)
  }

  const directionsTo = (cellId: string) => {
    const c = findCell(cellId)
    if (!c) return
    const t = placeFromCell(c)
    const f = from && from.id !== t.id ? from : (mode === 'elevator' ? accessibleEntrancePlace : entrancePlace)(c.building)
    runRoute(f, t)
  }

  const startHere = (cellId: string) => {
    const c = findCell(cellId)
    if (!c) return
    const f = placeFromCell(c)
    setFrom(f)
    if (to && to.id !== f.id) runRoute(f, to)
  }

  const directions = (
    <DirectionsCard
      from={from}
      to={to}
      mode={mode}
      route={route}
      activeStep={activeStep}
      suggestions={suggestions}
      onFrom={setFrom}
      onTo={setTo}
      onMode={(m) => {
        setMode(m)
        if (route && from && to) runRoute(from, to, m)
      }}
      onSwap={() => {
        setFrom(to)
        setTo(from)
        if (route && from && to) runRoute(to, from)
      }}
      onGo={() => from && to && runRoute(from, to)}
      onRandom={randomRoute}
      onClear={clearRoute}
      onStep={(i) => goToStep(i)}
    />
  )

  const routeFloors =
    route && view.type === 'building'
      ? route.legs.flatMap((l) => (l.kind === 'indoor' && l.building === view.code ? l.floors : []))
      : []

  return (
    <div className="flex h-full flex-col">
      <Header active={nav} onNav={onNav} onRoadmap={() => setRoadmap(true)} />
      <main className="flex min-h-0 flex-1 max-md:flex-col-reverse">
        <aside
          ref={sidebarRef}
          className="scrollbar-thin w-[400px] shrink-0 overflow-y-auto border-r border-neutral-200 bg-white max-md:w-full max-md:flex-1 max-md:border-r-0 max-md:border-t"
        >
          {view.type === 'campus' ? (
            <div key="campus" className="animate-fade-up space-y-6 p-4">
              <SearchBox onPlace={openPlace} onBuilding={(c) => openBuilding(c)} />
              <WelcomeCard persona={persona} onPersona={setPersona} onCta={welcomeCta} onAccessible={() => onNav('accessibility')} />
              {directions}
              <div ref={eventsRef} className="scroll-mt-4">
                <EventList filter={eventFilter} onFilter={setEventFilter} onOpen={openEvent} />
              </div>
              <BuildingGrid onOpen={(c) => openBuilding(c)} />
            </div>
          ) : (
            <div key={view.code} className="animate-fade-up space-y-6 p-4">
              <BuildingHeader code={view.code} onBack={() => setView({ type: 'campus' })} />
              {selectedCell && (
                <SelectedRoomCard
                  key={selectedCell}
                  cellId={selectedCell}
                  onDirectionsTo={() => directionsTo(selectedCell)}
                  onStartHere={() => startHere(selectedCell)}
                  onClose={() => setSelectedCell(undefined)}
                />
              )}
              {directions}
              <FloorDirectory
                code={view.code}
                floor={view.floor}
                highlights={highlights}
                selected={selectedCell}
                onSelect={selectCell}
                onRandom={() => {
                  const p = randomRoomPlace(view.code)
                  setView({ type: 'building', code: view.code, floor: p.floor })
                  setSelectedCell(p.id)
                }}
              />
              <div ref={eventsRef} className="scroll-mt-4">
                <EventList filter={eventFilter} onFilter={setEventFilter} onOpen={openEvent} building={view.code} />
              </div>
            </div>
          )}
        </aside>

        <div className="relative min-w-0 flex-1 bg-white max-md:h-[52vh] max-md:flex-none">
          <MapCanvas
            view={view}
            layers={layers}
            route={route}
            highlights={highlights}
            selectedCell={selectedCell}
            onSelectBuilding={(c) => openBuilding(c)}
            onSelectCell={selectCell}
            onSelectFloor={(f) => view.type === 'building' && setView({ ...view, floor: f })}
          />
          <Breadcrumb view={view} onCampus={() => setView({ type: 'campus' })} />
          {view.type === 'campus' && !route && <CampusHint />}
          {route && <RouteBar route={route} active={activeStep} onStep={(i) => goToStep(i)} onClose={clearRoute} />}
          {view.type === 'building' && (
            <FloorSelector
              levels={getLevels(view.code)}
              floor={view.floor}
              routeFloors={routeFloors}
              onSelect={(f) => setView({ ...view, floor: f })}
            />
          )}
          <LayerPanel
            layers={layers}
            view={view}
            onToggle={(k) =>
              setLayers((l) => {
                const n = new Set(l)
                if (n.has(k)) n.delete(k)
                else n.add(k)
                return n
              })
            }
          />
        </div>
      </main>
      <RoadmapSheet open={roadmap} onClose={() => setRoadmap(false)} />
    </div>
  )
}
