/** Static loading shell shown while the client app hydrates. Server-renderable. */
export function AppShellFallback() {
  return (
    <div className="flex h-full flex-col">
      <header className="flex h-14 shrink-0 items-center gap-3 bg-cardinal px-4 text-white md:px-6">
        <span className="font-display text-[26px] font-bold leading-none tracking-tight">USC</span>
        <span className="h-7 w-px bg-white/30" />
        <span className="leading-tight">
          <span className="block text-[15px] font-semibold">Trojan Wayfinder</span>
          <span className="block text-[11px] uppercase tracking-[0.14em] text-white/70">Campus Maps · Indoor 3D</span>
        </span>
      </header>
      <main className="flex min-h-0 flex-1 max-md:flex-col-reverse">
        <aside className="w-[400px] shrink-0 space-y-4 border-r border-neutral-200 p-4 max-md:w-full">
          <div className="h-11 animate-pulse rounded-lg bg-neutral-100" />
          <div className="h-64 animate-pulse rounded-xl bg-neutral-100" />
          <div className="h-48 animate-pulse rounded-xl bg-neutral-100" />
        </aside>
        <MapLoading />
      </main>
    </div>
  )
}

export function MapLoading() {
  return (
    <div className="grid min-w-0 flex-1 place-items-center bg-white max-md:h-[52vh] max-md:flex-none">
      <div className="flex items-center gap-3 text-[14px] font-medium text-neutral-500">
        <span className="h-5 w-5 animate-spin rounded-full border-2 border-neutral-200 border-t-cardinal" />
        Loading 3D campus…
      </div>
    </div>
  )
}
